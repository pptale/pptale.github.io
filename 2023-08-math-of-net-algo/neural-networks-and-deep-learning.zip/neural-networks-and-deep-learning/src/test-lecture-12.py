import mnist_loader
training_data, validation_data, test_data = mnist_loader.load_data_wrapper()
print("training_data", len(training_data), "validation_data", len(validation_data), "test_data", len(test_data))

#for t in training_data[0]:
#    print(type(t), len(t))

import network
net = network.Network([784, 30, 10])

#for b in net.biases:
#   print(type(b),len(b))

#for w in net.weights:
#    print(len(w),len(w[0]))

net.SGD(training_data , epochs=30, mini_batch_size=10, eta=3.0, test_data=test_data)